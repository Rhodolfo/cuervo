# cuervo
project cuervo... as stupid as it gets
